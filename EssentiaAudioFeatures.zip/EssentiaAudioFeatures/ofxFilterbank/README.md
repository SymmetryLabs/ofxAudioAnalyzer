# ofxFilterbank 

Introduction
--------
[openFrameworks](http://openframeworks.cc/) addon for polyphonic pitch detection in an audio signal. It implements a bank of resonant audio filters centered at each frequency of the musical temperament.

Demo video: https://vimeo.com/129795471 


Installation
-----------
Copy to your openFrameworks/addons folder.


Compatibility
---------
openFrameworks 0.90

